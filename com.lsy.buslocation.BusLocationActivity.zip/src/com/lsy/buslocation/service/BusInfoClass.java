package com.lsy.buslocation.service;

public class BusInfoClass
{
	//	SERVICE COMMAND
	public static final int		GET_BUS_ROUTE_INFO							= 0;
	public static final int		GET_BUS_ROUTE_LIST							= 1;
	public static final int		GET_BUS_ROUTE_PATH							= 2;
	public static final int		GET_BUS_STATION_BY_ROUTE					= 3;

	public static final int		GET_STATION_BY_NAME							= 4;
	public static final int		GET_LOW_STATION_BY_NAME						= 5;
	public static final int		GET_STATION_BY_UID							= 6;
	public static final int		GET_STATION_BY_POS							= 7;
	
	public static final int		GET_BUS_ROUTE_BY_STATION					= 8;

	public static final int		GET_BUS_POS_BY_RTID							= 9;
	public static final int		GET_BUS_POS_BY_RTST							= 10;
	
	public static final int		GET_ARRIVE_INFO_BY_ROUTE					= 11;

	//	ERROR CODE
	public static final int		PERFORM_RESULT_OK							= 0;
	public static final int		PERFORM_RESULT_SYSTEM_ERROR					= 1;
	public static final int		PERFORM_RESULT_NO_MANDATORY_PARAM			= 2;
	public static final int		PERFORM_RESULT_BAD_MANDATORY_PARAM			= 3;
	public static final int		PERFORM_RESULT_NO_RESULT					= 4;
	public static final int		PERFORM_RESULT_NO_SVC_KEY					= 5;
	public static final int		PERFORM_RESULT_NOT_REGISTERED_SVC_KEY		= 6;
	public static final int		PERFORM_RESULT_CAN_NOT_USED_SVC_KEY			= 7;
	public static final int		PERFORM_RESULT_OVER_REQUEST_LIMIT			= 8;
	public static final int		PERFORM_RESULT_BAD_POSITION					= 20;
	public static final int		PERFORM_RESULT_INPUT_MORE_ROUTE_NUM			= 21;
	public static final int		PERFORM_RESULT_INPUT_MORE_STATION_INFO		= 22;
	public static final int		PERFORM_RESULT_NO_ARRIVE_INFO				= 23;
	public static final int		PERFORM_RESULT_NO_ST_STATION_ID				= 31;
	public static final int		PERFORM_RESULT_NO_ED_STATION_ID				= 32;
	public static final int		PERFORM_RESULT_PREPARE_SERVICE				= 99;
}
