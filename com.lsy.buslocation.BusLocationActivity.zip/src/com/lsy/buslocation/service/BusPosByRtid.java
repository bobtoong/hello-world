package com.lsy.buslocation.service;

import org.w3c.dom.Node;

import com.google.android.maps.GeoPoint;

import android.util.Log;

public class BusPosByRtid extends BusInfoSuperClass
{

	private BusRouteClass	busRoute	= null;
	@Override
	String makeAddress(Object... params)
	{
		if (params.length != 1)
		{
			Log.e(TAG, "BusPosByRtid makeAddress's argument is not 1");
			return null;
		}
		busRoute	= (BusRouteClass)params[0];
		Log.i(TAG, "BusPosByRtid makeAddress(" + params[0] + ")");
		BusLocation		busLocation		= new BusLocation();
		return  busLocation.MakeAddr(BusInfoClass.GET_BUS_POS_BY_RTID, busRoute.getBusRouteId()/*routeId*/);
	}

	@Override
	Object getNewObject()
	{
		// TODO Auto-generated method stub
		return new BusPosClass();
	}

	@Override
	void getNodeElement(Object object, Node elementNode)
	{
		BusPosClass	busPos	= (BusPosClass)object;

		if (elementNode.getNodeName().equals("sectOrd"))
		{
			busPos.setSectOrd(elementNode.getTextContent());
			busPos.setBusRouteId(busRoute.getBusRouteId());
			busPos.setBusRouteNm(busRoute.getBusRouteNm());
			busPos.setRouteType(busRoute.getRouteType());
		}
		else if (elementNode.getNodeName().equals("fullSectDist"))
		{
			busPos.fullSectDist	= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("sectDist"))
		{
			busPos.sectDist		= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("rtDist"))
		{
			busPos.rtDist			= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("stopFlag"))
		{
			busPos.stopFlag		= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("sectionId"))
		{
			busPos.setSectionId(elementNode.getTextContent());
//			busPos.sectionId		= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("dataTm"))
		{
			busPos.dataTm			= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("gpsX"))
		{
			busPos.gpsX			= elementNode.getTextContent(); 
			busPos.setLongitudeE6((int)(Double.parseDouble(busPos.gpsX)*1E6));	// 	gpsX * 1E6

			if (busPos.getLatitudeE6() > 0 && busPos.getLongitudeE6() > 0)
			{
				busPos.setPosition(new GeoPoint(busPos.getLatitudeE6(), busPos.getLongitudeE6()));
			}
		} 
		else if (elementNode.getNodeName().equals("gpsY"))
		{
			busPos.gpsY			= elementNode.getTextContent(); 
			busPos.setLatitudeE6((int)(Double.parseDouble(busPos.gpsY)*1E6));		//	gpsY * 1E6

			if (busPos.getLatitudeE6() > 0 && busPos.getLongitudeE6() > 0)
			{
				busPos.setPosition(new GeoPoint(busPos.getLatitudeE6(), busPos.getLongitudeE6()));
			}
		} 
		else if (elementNode.getNodeName().equals("vehId"))
		{
			busPos.setVehId(elementNode.getTextContent()); 
		}
		else if (elementNode.getNodeName().equals("plainNo"))
		{
			busPos.setPlainNo(elementNode.getTextContent()); 
		} 
		else if (elementNode.getNodeName().equals("busType"))
		{
			busPos.busType			= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("lastStTm"))
		{
			busPos.lastStTm		= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("lastStnId"))
		{
			busPos.setLastStnId(elementNode.getTextContent());
//			busPos.lastStnId	= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("lastStnOrd"))
		{
			busPos.setLastStnOrd(elementNode.getTextContent());
		} 
		else if (elementNode.getNodeName().equals("nextStTm"))
		{
			busPos.nextStTm		= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("isrunyn"))
		{
			busPos.isrunyn			= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("trnstnid"))
		{
			busPos.trnstnid		= elementNode.getTextContent(); 
		} 
		else if (elementNode.getNodeName().equals("lstbusyn"))
		{
			busPos.lstbusyn		= elementNode.getTextContent(); 
		} 
	}
}
