package com.lsy.buslocation.service;

import org.w3c.dom.Node;

import android.util.Log;

public class ArriveInfoByRoute extends BusInfoSuperClass
{

	@Override
	String makeAddress(Object... params)
	{
		if (params.length != 3)
		{
			Log.e(TAG, "ArriveInfoByRoute makeAddress's argument is not 3");
			return null;
		}
		Log.i(TAG, "ArriveInfoByRoute makeAddress(" + params[0] + ", " + params[1] + ", " + params[2] + ")");
		BusLocation		busLocation		= new BusLocation();
		return  busLocation.MakeAddr(BusInfoClass.GET_ARRIVE_INFO_BY_ROUTE, (String)params[0]/*stId*/, (String)params[1]/*busRouteId*/, (String)params[2]/*ord*/);
	}

	@Override
	Object getNewObject()
	{
		return new BusArriveInfoClass();
	}

	@Override
	void getNodeElement(Object object, Node elementNode)
	{
		BusArriveInfoClass	busArriveInfo	= (BusArriveInfoClass)object;

		if (elementNode.getNodeName().equals("stId"))
		{
			busArriveInfo.stId		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("stNm"))
		{
			busArriveInfo.stNm		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("arsId"))
		{
			busArriveInfo.arsId		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("busRouteId"))
		{
			busArriveInfo.setBusRouteId(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("rtNm"))
		{
			busArriveInfo.rtNm		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("firstTm"))
		{
			busArriveInfo.firstTm		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("lastTm"))
		{
			busArriveInfo.lastTm		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("term"))
		{
			busArriveInfo.term		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("routeType"))
		{
			busArriveInfo.routeType		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nextBus"))
		{
			busArriveInfo.nextBus		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("staOrd"))
		{
			busArriveInfo.staOrd		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("dir"))
		{
			busArriveInfo.dir		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("mkTm"))
		{
			busArriveInfo.mkTm		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("vehId1"))
		{
			busArriveInfo.setVehId1(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("plainNo1"))
		{
			busArriveInfo.setPlainNo1(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("sectOrd1"))
		{
			busArriveInfo.sectOrd1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("stationNm1"))
		{
			busArriveInfo.stationNm1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("traTime1"))
		{
			busArriveInfo.traTime1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("traSpd1"))
		{
			busArriveInfo.traSpd1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("isArrive1"))
		{
			busArriveInfo.isArrive1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("repTm1"))
		{
			busArriveInfo.repTm1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("isLast1"))
		{
			busArriveInfo.isLast1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("busType1"))
		{
			busArriveInfo.busType1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("avgCf1"))
		{
			busArriveInfo.avgCf1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("expCf1"))
		{
			busArriveInfo.expCf1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("kalCf1"))
		{
			busArriveInfo.kalCf1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("neuCf1"))
		{
			busArriveInfo.neuCf1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("exps1"))
		{
			busArriveInfo.exps1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("kals1"))
		{
			busArriveInfo.kals1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("neus1"))
		{
			busArriveInfo.neus1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("rerdie_Div1"))
		{
			busArriveInfo.rerdie_Div1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("reride_Num1"))
		{
			busArriveInfo.reride_Num1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("brerde_Div1"))
		{
			busArriveInfo.brerde_Div1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("brdrde_Num1"))
		{
			busArriveInfo.brdrde_Num1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("full1"))
		{
			busArriveInfo.full1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nstnId1"))
		{
			busArriveInfo.nstnId1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nstnOrd1"))
		{
			busArriveInfo.nstnOrd1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nstnSpd1"))
		{
			busArriveInfo.nstnSpd1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nstnSec1"))
		{
			busArriveInfo.nstnSec1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmainStnid1"))
		{
			busArriveInfo.nmainStnid1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmainOrd1"))
		{
			busArriveInfo.nmainOrd1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmainSec1"))
		{
			busArriveInfo.nmainSec1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain2Stnid1"))
		{
			busArriveInfo.nmain2Stnid1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain2Ord1"))
		{
			busArriveInfo.nmain2Ord1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("namin2Sec1"))
		{
			busArriveInfo.namin2Sec1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain3Stnid1"))
		{
			busArriveInfo.nmain3Stnid1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain3Ord1"))
		{
			busArriveInfo.nmain3Ord1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain3Sec1"))
		{
			busArriveInfo.nmain3Sec1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("goal1"))
		{
			busArriveInfo.goal1		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("vehId2"))
		{
			busArriveInfo.setVehId2(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("plainNo2"))
		{
			busArriveInfo.plainNo2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("sectOrd2"))
		{
			busArriveInfo.sectOrd2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("stationNm2"))
		{
			busArriveInfo.stationNm2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("traTime2"))
		{
			busArriveInfo.traTime2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("traSpd2"))
		{
			busArriveInfo.traSpd2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("isArrive2"))
		{
			busArriveInfo.isArrive2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("repTm2"))
		{
			busArriveInfo.repTm2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("isLast2"))
		{
			busArriveInfo.isLast2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("busType2"))
		{
			busArriveInfo.busType2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("avgCf2"))
		{
			busArriveInfo.avgCf2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("expCf2"))
		{
			busArriveInfo.expCf2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("kalCf2"))
		{
			busArriveInfo.kalCf2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("neuCf2"))
		{
			busArriveInfo.neuCf2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("exps2"))
		{
			busArriveInfo.exps2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("kals2"))
		{
			busArriveInfo.kals2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("neus2"))
		{
			busArriveInfo.neus2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("rerdie_Div2"))
		{
			busArriveInfo.rerdie_Div2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("reride_Num2"))
		{
			busArriveInfo.reride_Num2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("brerde_Div2"))
		{
			busArriveInfo.brerde_Div2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("brdrde_Num2"))
		{
			busArriveInfo.brdrde_Num2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("full2"))
		{
			busArriveInfo.full2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nstnId2"))
		{
			busArriveInfo.nstnId2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nstnOrd2"))
		{
			busArriveInfo.nstnOrd2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nstnSpd2"))
		{
			busArriveInfo.nstnSpd2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nstnSec2"))
		{
			busArriveInfo.nstnSec2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmainStnid2"))
		{
			busArriveInfo.nmainStnid2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmainOrd2"))
		{
			busArriveInfo.nmainOrd2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmainSec2"))
		{
			busArriveInfo.nmainSec2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain2Stnid2"))
		{
			busArriveInfo.nmain2Stnid2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain2Ord2"))
		{
			busArriveInfo.nmain2Ord2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("namin2Sec2"))
		{
			busArriveInfo.namin2Sec2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain3Stnid2"))
		{
			busArriveInfo.nmain3Stnid2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain3Ord2"))
		{
			busArriveInfo.nmain3Ord2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nmain3Sec2"))
		{
			busArriveInfo.nmain3Sec2		= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("goal2"))
		{
			busArriveInfo.goal2		= elementNode.getTextContent();
		}
	}

}
