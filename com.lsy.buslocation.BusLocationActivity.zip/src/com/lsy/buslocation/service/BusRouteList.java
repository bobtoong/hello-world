package com.lsy.buslocation.service;

//import java.util.LinkedList;

import android.util.Log;

//import com.lsy.buslocation.*;

import org.w3c.dom.Node;
//import org.w3c.dom.NodeList;

public class BusRouteList extends BusInfoSuperClass
{

	String makeAddress(Object ... params)
	{
		if (params.length != 1)
		{
			Log.e(TAG, "BusRouteList makeAddress's argument is not 1");
			return null;
		}
		Log.i(TAG, "BusRouteList makeAddress(" + params[0] + ")");
		BusLocation		busLocation		= new BusLocation();
		return busLocation.MakeAddr(BusInfoClass.GET_BUS_ROUTE_LIST, (String)params[0]/*routeId*/);
	}

	Object getNewObject()
	{
		return (Object)new BusRouteClass();
	}

	void getNodeElement(Object object, Node elementNode)
	{
		BusRouteClass	busRoute	= (BusRouteClass)object;

		if (elementNode.getNodeName().equals("busRouteId"))
		{
			busRoute.setBusRouteId(elementNode.getTextContent()); 
		}
		else if (elementNode.getNodeName().equals("busRouteNm"))
		{
			busRoute.setBusRouteNm(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("length"))
		{
			busRoute.length	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("routeType"))
		{
			busRoute.setRouteType(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("stStationNm"))
		{
			busRoute.stStationNm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("edStationNm"))
		{
			busRoute.edStationNm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("term"))
		{
			busRoute.term	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("lastBusYn"))
		{
			busRoute.lastBusYn	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("lastBusTm"))
		{
			busRoute.lastBusTm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("firstBusTm"))
		{
			busRoute.firstBusTm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("lastLowTm"))
		{
			busRoute.lastLowTm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("firstLowTm"))
		{
			busRoute.firstLowTm	= elementNode.getTextContent();
		}
	}
}

/*
	public BusRoute	getInfo(String RouteID)
	{
		int				nNodeCount;
		BusLocation		busLocation		= new BusLocation();
		ParseXML		ParseObj		= new ParseXML();
		Node			node			= null;

		String			busInfoAddr		= busLocation.MakeAddr(BusInfoClass.GET_BUS_ROUTE_LIST, RouteID, "", "", "");
		String			busInfo			= busLocation.DownLoadHtml(busInfoAddr);

		nNodeCount	= ParseObj.Parse(busInfo);
		if (ParseObj.isOK() != true)
		{
			//toast popup, ������ ���� ���̻� ���� ����.
			return null;
		}

		for (int i=0; i < nNodeCount; i++)
		{
			node	= ParseObj.getNode(i);
			if (node.getNodeName().equals("msgBody"))
			{
				node		= node.getFirstChild();
				break;
			}
		}

		while (node != null)
		{
			if (node.getNodeName().equals("itemList"))
			{
				BusRoute	busRoute		= new BusRoute();
				NodeList	nodeList	= node.getChildNodes();
				int			nodeCount;
				if (nodeList == null)
					break;
				nodeCount	= nodeList.getLength();
				for (int i = 0; i < nodeCount; i++)
				{
					Node	elementNode = nodeList.item(i);
					if (elementNode.getNodeName().equals("busRouteId"))
					{
						busRoute.busRouteId	= elementNode.getTextContent(); 
					}
					else if (elementNode.getNodeName().equals("busRouteNm"))
					{
						busRoute.busRouteNm	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("length"))
					{
						busRoute.length	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("routeType"))
					{
						busRoute.routeType	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("stStationNm"))
					{
						busRoute.stStationNm	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("edStationNm"))
					{
						busRoute.edStationNm	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("term"))
					{
						busRoute.term	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("lastBusYn"))
					{
						busRoute.lastBusYn	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("lastBusTm"))
					{
						busRoute.lastBusTm	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("firstBusTm"))
					{
						busRoute.firstBusTm	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("lastLowTm"))
					{
						busRoute.lastLowTm	= elementNode.getTextContent();
					}
					else if (elementNode.getNodeName().equals("firstLowTm"))
					{
						busRoute.firstLowTm	= elementNode.getTextContent();
					}
				}
				busRouteListNode.add(busRoute);
			}
			node	= node.getNextSibling();
		}
		return (BusRoute)busRouteListNode.getFirst();
	}
*/