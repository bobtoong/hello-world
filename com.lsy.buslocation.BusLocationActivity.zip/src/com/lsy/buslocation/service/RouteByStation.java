package com.lsy.buslocation.service;

//import java.util.LinkedList;

import org.w3c.dom.Node;
//import org.w3c.dom.NodeList;

import android.util.Log;

public class RouteByStation extends BusInfoSuperClass
{

	String makeAddress(Object ... params)
	{
		if (params.length != 1)
		{
			Log.e(TAG, "RouteByStation makeAddress's argument is not 1");
			return null;
		}
		Log.i(TAG, "RouteByStation makeAddress(" + params[0] + ")");
		BusLocation		busLocation		= new BusLocation();
		return  busLocation.MakeAddr(BusInfoClass.GET_BUS_ROUTE_BY_STATION, (String)params[0]/*arsId*/);
	}

	Object getNewObject()
	{
		return new BusRouteClass();
	}

	void getNodeElement(Object object, Node elementNode)
	{
		BusRouteClass	busRoute	= (BusRouteClass)object;
		
		if (elementNode.getNodeName().equals("busRouteId"))
		{
			busRoute.setBusRouteId(elementNode.getTextContent()); 
		}
		else if (elementNode.getNodeName().equals("busRouteNm"))
		{
			busRoute.setBusRouteNm(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("length"))
		{
			busRoute.length	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("busRouteType"))
		{
			busRoute.setRouteType(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("stBegin"))
		{
			busRoute.stStationNm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("stEnd"))
		{
			busRoute.edStationNm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("term"))
		{
			busRoute.term	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("nextBus"))
		{
			busRoute.lastBusYn	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("firstBusTm"))
		{
			busRoute.firstBusTm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("lastBusTm"))
		{
			busRoute.lastBusTm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("firstBusTmLow"))
		{
			busRoute.firstLowTm	= elementNode.getTextContent();
		}
		else if (elementNode.getNodeName().equals("lastBusTmLow"))
		{
			busRoute.lastLowTm	= elementNode.getTextContent();
		}
	}

/*
	public BusRoutebyStation	getInfo(String arsId)
	{
		int				nNodeCount;
		BusLocation		busLocation		= new BusLocation();
		ParseXML		ParseObj		= new ParseXML();
		Node			node			= null;

		String			busInfoAddr		= busLocation.MakeAddr(BusInfoClass.GET_BUS_ROUTE_BY_STATION, arsId, "", "", "");
		String			busInfo			= busLocation.DownLoadHtml(busInfoAddr);

		nNodeCount	= ParseObj.Parse(busInfo);
		if (ParseObj.isOK() != true)
		{
			//toast popup, ������ ���� ���̻� ���� ����.
			return null;
		}

		for (int i=0; i < nNodeCount; i++)
		{
			node	= ParseObj.getNode(i);
			if (node.getNodeName().equals("msgBody"))
			{
				node		= node.getFirstChild();
				break;
			}
		}

		while (node != null)
		{
			if (node.getNodeName().equals("itemList"))
			{
				BusRoutebyStation	busRoute		= 
				NodeList	nodeList		= node.getChildNodes();
				int			nodeCount;
				if (nodeList == null)
					break;
				nodeCount	= nodeList.getLength();
				for (int i = 0; i < nodeCount; i++)
				{
					Node	elementNode = nodeList.item(i);


				}
				BusRouteByStationNode.add(busRoute);
			}
			node	= node.getNextSibling();
		}
		return (BusRoutebyStation)BusRouteByStationNode.getFirst();
	}
*/
}
