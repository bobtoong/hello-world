package com.lsy.buslocation.service;

import org.w3c.dom.Node;

import android.util.Log;

public class BusPosByRoutest extends BusInfoSuperClass
{
	private BusRouteClass	busRoute	= null;

	@Override
	String makeAddress(Object... params)
	{
		if (params.length != 3)
		{
			Log.e(TAG, "BusPosByRoutest makeAddress's argument is not 3");
			return null;
		}
		busRoute	= (BusRouteClass)params[0];
		Log.i(TAG, "BusPosByRoutest makeAddress(" + params[0] + ", " + params[1] + ", " + params[2] + ")");
		BusLocation		busLocation		= new BusLocation();
		return  busLocation.MakeAddr(BusInfoClass.GET_BUS_POS_BY_RTST, busRoute.getBusRouteId()/*busRouteId*/, (String)params[1]/*startOrd*/, (String)params[2]/*endOrd*/);
	}

	@Override
	Object getNewObject()
	{
		// TODO Auto-generated method stub
		return new BusPosClass();
	}

	@Override
	void getNodeElement(Object object, Node elementNode)
	{
		BusPosClass	busPos	= (BusPosClass)object;

	    //	��������
		if (elementNode.getNodeName().equals("sectOrd"))
		{
			busPos.setSectOrd(elementNode.getTextContent());
			busPos.setBusRouteId(busRoute.getBusRouteId());
			busPos.setBusRouteNm(busRoute.getBusRouteNm());
			busPos.setRouteType(busRoute.getRouteType());

//			busPos.sectOrd	= elementNode.getTextContent(); 
		}
	    //	�����ɼ°Ÿ�(Km)
		else if (elementNode.getNodeName().equals("sectDist"))
		{
			busPos.sectDist	= elementNode.getTextContent(); 
		}
	    //	�����ҵ������� (0:������, 1:����)
		else if (elementNode.getNodeName().equals("stopFlag"))
		{
			busPos.stopFlag	= elementNode.getTextContent(); 
		}
	    //	���� ID
		else if (elementNode.getNodeName().equals("sectionId"))
		{
			busPos.setSectionId(elementNode.getTextContent());
//			busPos.sectionId	= elementNode.getTextContent(); 
		}
	    //	�����ð�
		else if (elementNode.getNodeName().equals("dataTm"))
		{
			busPos.dataTm	= elementNode.getTextContent(); 
		} 
		//	�ʸ�ĪX��ǥ (WGS84)
		else if (elementNode.getNodeName().equals("tmX"))
		{
			busPos.gpsX	= elementNode.getTextContent(); 
			busPos.setLongitudeE6((int)(Double.parseDouble(busPos.gpsX)*1E6));	// 	gpsX * 1E6
		} 
		//	�ʸ�ĪY��ǥ (WGS84)
		else if (elementNode.getNodeName().equals("tmY"))
		{
			busPos.gpsY	= elementNode.getTextContent(); 
			busPos.setLatitudeE6((int)(Double.parseDouble(busPos.gpsY)*1E6));		//	gpsY * 1E6
		} 
		//	���� ID
		else if (elementNode.getNodeName().equals("vehId"))
		{
			busPos.setVehId(elementNode.getTextContent()); 
		} 
		//	������ȣ
		else if (elementNode.getNodeName().equals("plainNo"))
		{
			busPos.setPlainNo(elementNode.getTextContent()); 
		}
		//	�������� (0:�Ϲݹ���, 1:�������, 2:��������)
		else if (elementNode.getNodeName().equals("busType"))
		{
			busPos.busType	= elementNode.getTextContent(); 
		} 
	}

}
