package com.lsy.buslocation.service;

import java.util.LinkedList;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.lsy.buslocation.utility.ParseXML;

import android.util.Log;

public abstract class BusInfoSuperClass
{
	static final String				TAG = "BusLocation";
	public LinkedList<Object>		NodeList;

	public BusInfoSuperClass()
	{
		NodeList		= new LinkedList<Object>();
    }

	abstract String		makeAddress(Object ... params);
	abstract Object		getNewObject();
	abstract void		getNodeElement(Object object, Node elementNode);

	public Object	getInfo(Object ... params)
	{
		int				nNodeCount;
		BusLocation		busLocation		= new BusLocation();
		ParseXML		ParseObj		= new ParseXML();
		Node			node			= null;

		String			busInfoAddr		= makeAddress(params);
		String			busInfo			= busLocation.DownLoadHtml(busInfoAddr);

		NodeList.clear();
		if (busInfo.length() <= 0)
		{
			Log.e(TAG, "could not download XML!");
			return null;
		}
		nNodeCount	= ParseObj.Parse(busInfo);
		if (ParseObj.isOK() != true)
		{
			//toast popup, ������ ���� ���̻� ���� ����.
			Log.e(TAG, "getInfo parsing XML is no OK!");
			return null;
		}

		for (int i=0; i < nNodeCount; i++)
		{
			node	= ParseObj.getNode(i);
			if (node.getNodeName().equals("msgBody"))
			{
				node		= node.getFirstChild();
				break;
			}
		}

		int	itemCount	= 0;
		while (node != null)
		{
			if (node.getNodeName().equals("itemList"))
			{
				Object		object		= getNewObject();
//				BusRoute	busRoute	= new BusRoute();	// abstract
				NodeList	nodeList	= node.getChildNodes();
				int			nodeCount;
				if (nodeList == null)
					break;
				nodeCount	= nodeList.getLength();
				for (int i = 0; i < nodeCount; i++)
				{
					Node	elementNode = nodeList.item(i);
					getNodeElement(object, elementNode);
				}
				NodeList.add(object);
				itemCount++;
			}
			node	= node.getNextSibling();
		}
		Log.i(TAG, "getInfo itemCount is [" + itemCount + "]");

		return (Object)NodeList.getFirst();
	}

}
