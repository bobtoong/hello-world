package com.lsy.buslocation.service;

import com.google.android.maps.GeoPoint;

public class Station
{
	private String			stationId;				//	string	������ ID
	private String			stationNm;				//	string	�����Ҹ�
	String			gpsX;					//	string	������ ��ǥX
	String			gpsY;					//	string	������ ��ǥY
	String			arsId;					//	string	�����Ұ�����ȣ
	String			stationTp;				// ?
	private int				latitudeE6		= 0;	//	gpsY * 1E6
	private int				longitudeE6		= 0;	// 	gpsX * 1E6
	private GeoPoint		position		= null;

    public Station()
    {
    	setStationId("");				//	string	�뼱 ID
    	stationNm		= "";				//	string	�뼱��
    	gpsX			= "";				//	string	�뼱 ���� (Km)
    	gpsY			= "";				//	string	�뼱 ���� (1:����, 3:����, 4:����, 5:��ȯ, 6:����, 7:��õ, 8:���, 9:����, 0:����)
    	setArsId("");				//	string	����
    	stationTp		= "";
    }

    public String getStationNm()
    {
    	return stationNm;
    }

    public void setStationNm(String stationNm)
    {
    	this.stationNm = stationNm; 
    }

	public int getLatitudeE6()
	{
		return latitudeE6;
	}

	public void setLatitudeE6(int latitudeE6)
	{
		this.latitudeE6 = latitudeE6;
	}

	public int getLongitudeE6()
	{
		return longitudeE6;
	}

	public void setLongitudeE6(int longitudeE6)
	{
		this.longitudeE6 = longitudeE6;
	}


	public String getArsId()
	{
		return arsId;
	}


	public void setArsId(String arsId)
	{
		this.arsId = arsId;
	}


	public String getStationId()
	{
		return stationId;
	}

	public void setStationId(String stationId)
	{
		this.stationId = stationId;
	}

	public GeoPoint getPosition()
	{
		return position; 
	}

	public void setPosition(GeoPoint point)
	{
		this.position	= point;
	}
}
