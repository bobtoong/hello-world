package com.lsy.buslocation.service;

//import java.util.LinkedList;

import org.w3c.dom.Node;

import com.google.android.maps.GeoPoint;
//import org.w3c.dom.NodeList;

import android.util.Log;

public class StationByPos extends BusInfoSuperClass
{

	String makeAddress(Object ... params)
	{
		if (params.length != 3)
		{
			Log.e(TAG, "RouteByStation makeAddress's argument is not 3");
			return null;
		}
		Log.i(TAG, "RouteByStation makeAddress(" + params[0] + ", " + params[1] + ", " + params[2] + ")");
		BusLocation		busLocation		= new BusLocation();
		return  busLocation.MakeAddr(BusInfoClass.GET_STATION_BY_POS, (String)params[0]/*tmX*/, (String)params[1]/*tmY*/, (String)params[2]/*radius*/);
	}

	Object getNewObject()
	{
		return new Station();
	}

	void getNodeElement(Object object, Node elementNode)
	{
		Station	busStation	= (Station)object;

		if (elementNode.getNodeName().equals("stationId"))
		{
			busStation.setStationId(elementNode.getTextContent()); 
		}
		else if (elementNode.getNodeName().equals("stationNm"))
		{
			busStation.setStationNm(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("gpsX"))
		{
			busStation.gpsX				= elementNode.getTextContent();
			busStation.setLongitudeE6((int)(Double.parseDouble(busStation.gpsX)*1E6));	// 	gpsX * 1E6

			if (busStation.getLatitudeE6() > 0 && busStation.getLongitudeE6() > 0)
			{
				busStation.setPosition(new GeoPoint(busStation.getLatitudeE6(), busStation.getLongitudeE6()));
			}
		}
		else if (elementNode.getNodeName().equals("gpsY"))
		{
			busStation.gpsY				= elementNode.getTextContent();
			busStation.setLatitudeE6((int)(Double.parseDouble(busStation.gpsY)*1E6));	//	gpsY * 1E6

			if (busStation.getLatitudeE6() > 0 && busStation.getLongitudeE6() > 0)
			{
				busStation.setPosition(new GeoPoint(busStation.getLatitudeE6(), busStation.getLongitudeE6()));
			}
		}
		else if (elementNode.getNodeName().equals("arsId"))
		{
			busStation.setArsId(elementNode.getTextContent());
		}
		else if (elementNode.getNodeName().equals("stationTp"))
		{
			busStation.stationTp	= elementNode.getTextContent();
		}
	}
}
