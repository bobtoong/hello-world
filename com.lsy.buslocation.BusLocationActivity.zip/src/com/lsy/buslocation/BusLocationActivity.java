package com.lsy.buslocation;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
//import android.widget.Toast;

import com.google.android.maps.*;
//import android.graphics.drawable.*;
import android.location.*;

import com.lsy.buslocation.service.*;
import com.lsy.buslocation.utility.*;

public class BusLocationActivity extends MapActivity
{
	private static final String				TAG							= "BusLocation";

	private MapView							mapView;
	private MapController					mapControl;
    private MyPositionOverlay				myPositionOverlay;
    private StationOverlay					stationOverlay;
    private BusOverlay						yellowBusOverlay;
    private BusOverlay						greenBusOverlay;
    private BusOverlay						redBusOverlay;
    private BusOverlay						blueBusOverlay;
    private boolean							bInit						= false;
    //	��û
//	private Double							myLat	 					= 37566000.0;
//	private Double							myLng						= 126980500.0;
	//	����â ��
    private Double							myLat						= 37547427.0;
	private Double							myLng						= 126932022.0;

	private LocationManager					myLocationManager			= null;
    private LocationListener				myLocationListener			= null;

	private CountDownTimer 					_timer					 	= null;
	private Station							selectedstation				= null;
	private boolean							useArriveInfo				= false;


    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
//        Log.i(TAG, "onCreate");

        setContentView(R.layout.main);

        mapView			= (MapView) findViewById(R.id.mapview);
        mapControl		= mapView.getController();
        mapControl.setZoom(18);

        mapView.setBuiltInZoomControls(true);
        //GeoPoint pt = new GeoPoint(37881311, 127729968); //��õ
        //					����,      		����
        //					���� ũ�� ����,	���� ũ�� ����
        //GeoPoint pt = new GeoPoint(37567000, 126980000);
        //mapControl.setCenter(pt);
        GeoPoint point	=getMyLocation(); 
        if (point != null)
        {
        	Log.i(TAG, "getMyLocation returned Lat of point:"+ point.getLatitudeE6() + ", Lng  of point: " + point.getLongitudeE6());
	        Log.i(TAG, "getMyLocation returned Lat:"+ myLat + ", " + "Lng: " + myLng);

	        //mapView.getController().animateTo(getMyLocation());
	        mapControl.setCenter(point);
        }
        else
        {
        	//point		= new GeoPoint(37566000, 126980500);	//	��û
        	point		= new GeoPoint(37547427, 126932022);	//	����â ��
        }

        myPositionOverlay		= new MyPositionOverlay(this.getResources().getDrawable(R.drawable.myposition), mapView);
        stationOverlay			= new StationOverlay(this.getResources().getDrawable(R.drawable.bus_stop), mapView);
        yellowBusOverlay		= new BusOverlay(this.getResources().getDrawable(R.drawable.bus_yellow), mapView);
        greenBusOverlay			= new BusOverlay(this.getResources().getDrawable(R.drawable.bus_green), mapView);
        redBusOverlay			= new BusOverlay(this.getResources().getDrawable(R.drawable.bus_red), mapView);
        blueBusOverlay			= new BusOverlay(this.getResources().getDrawable(R.drawable.bus_blue), mapView);

        stationOverlay.setBusLocationActivity(this);
        // �ּ� ����
        Log.i(TAG, "Marker's position is  Lat:"+ point.getLatitudeE6() + ", " + "Lng: " + point.getLongitudeE6());

        myPositionOverlay.setItem(point);

        StationByPos 	busStationList		= new StationByPos();

        busStationList.getInfo("126.932022", "37.547427", "100");	//	����â
//        busStationList.getInfo("126.980500", "37.566000", "100");	//	��û
        for (int i = 0; i < busStationList.NodeList.size(); i++)
        {
        	Station station			= (Station)busStationList.NodeList.get(i);

        	stationOverlay.addItem(station.getPosition(), station);
        }
        //drawBusNearStation((Station)busStationList.NodeList.get(0));

        _timer = new CountDownTimer(10*60*1000, 60*1000)
        {
            public void onTick(long millisUntilFinished)
            {
            	Log.i(TAG, "timer is expired");
            	if (selectedstation != null)
            	{
            		drawBusNearStation(selectedstation);
            		mapView.invalidate();
            	}
            }

            public void onFinish()
            {
            	selectedstation	= null;
            }
        }.start();
/*
        {
    	    Pop pop;

    		Log.i(TAG,"onclick");
    		pop = new Pop(mapView);
    		pop.show();  //popview�� ���
        }
*/
        //Log.i(TAG, "stationOverlay count "+ stationOverlay.size() + "busOverlay count " + yellowBusOverlay.size());
    }

    public void drawBusNearStation(Station station)
    {
		if (useArriveInfo)
		{
	    	BusRouteClass	busRoute;
	    	RouteByStation	routeByStation		= new RouteByStation();
	    	routeByStation.getInfo(station.getArsId());
	        yellowBusOverlay.clear();
	    	for (int i = routeByStation.NodeList.size() - 1; i >= 0; i--)
	    	{
	    		busRoute	= (BusRouteClass)routeByStation.NodeList.get(i);
	    		drawBusNearStationByRoute(station, busRoute);
	    	}
		}
		else
		{
	    	if (selectedstation == null)
	    	{
	    		_timer.start();
	        	selectedstation								= station;
	    	}
	    	greenBusOverlay.clear();
	        yellowBusOverlay.clear();
	        blueBusOverlay.clear();
	        redBusOverlay.clear();
	    	RetrieveBusNearStation	retrieveBusNearStation	= new RetrieveBusNearStation();
	        ArrayList<BusPosClass>	busPosArray				= retrieveBusNearStation.findBusNearStation(station);
	        if (busPosArray == null)
	        {
	        	return;
	        }

	        BusPosClass				busPos;
	        int						arraySize				= busPosArray.size();
	
	        for (int i = 0; i < arraySize; i++)
	        {
	        	busPos					= busPosArray.get(i);
	        	Log.i(TAG, "drawBusNearStation bus routetype " +  busPos.getRouteType());
	        	//	(1:����, 3:����, 4:����, 5:��ȯ, 6:����, 7:��õ, 8:���, 9:����, 0:����)
	        	switch (Integer.parseInt(busPos.getRouteType()))
	        	{
	        	case 3 :
	            	greenBusOverlay.addItem(busPos.getPosition(), busPos);
	        		break;
	        	case 4 :
	            	blueBusOverlay.addItem(busPos.getPosition(), busPos);
	        		break;
	        	case 5 :
	            	yellowBusOverlay.addItem(busPos.getPosition(), busPos);
	        		break;
	        	case 6 :
	            	redBusOverlay.addItem(busPos.getPosition(), busPos);
	        		break;
	        	case 0 :
	        	case 1 :
	        	case 7 :
	        	case 8 :
	        		break;
	        	case 9 :
	        		break;
	        	}
	        	Log.i(TAG, busPos.getBusRouteNm() + "�� ���� �߰�, ���� ��ȣ " + busPos.getPlainNo() + " SectOrd " + busPos.getSectOrd() + " SectionId " + busPos.getSectionId()
	        			+ " lastStnId " + busPos.getLastStnId());
	        }
		}
//        stationOverlay.clear();
    }

    public void drawBusNearStationByRoute(Station station, BusRouteClass busRoute)
    {
        //	���� ���� ���� �˻�
    	ArriveInfoByRoute	arriveInfoByRoute	= new ArriveInfoByRoute();    	
    	BusArriveInfoClass	busArriveInfo		= (BusArriveInfoClass)arriveInfoByRoute.getInfo(station.getStationId(), busRoute.getBusRouteId(), "2");
    	if (busArriveInfo == null)
    	{
    		return;
    	}

//    	RetrieveBusNearStation	retrieveBusNearStation	= new RetrieveBusNearStation();
//      ArrayList<BusPosClass>	busPosArray				= retrieveBusNearStation.findBusNearStation(station);
    	
    	// �����Ҹ� ������ ���� ���� Ȯ��
    	BusPosByRtid			busPosByRtid			= new BusPosByRtid();
        BusPosClass		busPos;

        //	�� ������ ���ļ� �����ҿ� ���� ���� ���� �������� Ȯ�� ��
    	for (int i = arriveInfoByRoute.NodeList.size() - 1; i >= 0; i--)
    	{
    		busArriveInfo	= (BusArriveInfoClass)arriveInfoByRoute.NodeList.get(i);
        	busPosByRtid.getInfo(busArriveInfo.getBusRouteId());
            int				listSize					= busPosByRtid.NodeList.size();
            if (listSize <= 0)
            {
            	continue;
            }

    		for (int j = 0; j < listSize; j++)
    		{
            	busPos					= (BusPosClass)busPosByRtid.NodeList.get(i);

    			if (busArriveInfo.getVehId1().equals(busPos.getVehId()))
    			{
    				yellowBusOverlay.addItem(busPos.getPosition(), busPos);
    	        	Log.i(TAG, busPos.getBusRouteNm() + "�� ���� �߰�, ���� ��ȣ " + busPos.getPlainNo() + " SectOrd " + busPos.getSectOrd() + " SectionId " + busPos.getSectionId()
    	        			+ " lastStnId " + busPos.getLastStnId());
    			}
    			else if (busArriveInfo.getVehId2().equals(busPos.getVehId()))
    			{
    				yellowBusOverlay.addItem(busPos.getPosition(), busPos);
    	        	Log.i(TAG, busPos.getBusRouteNm() + "�� ���� �߰�, ���� ��ȣ " + busPos.getPlainNo() + " SectOrd " + busPos.getSectOrd() + " SectionId " + busPos.getSectionId()
    	        			+ " lastStnId " + busPos.getLastStnId());
    			}
    		}
    	}
    }

    @Override
    protected boolean isRouteDisplayed()
    {
        return false;
    }

    private String changeProvider()
    {
    	String Provider;
	    Criteria c;

	    c				= new Criteria();
	    c.setAccuracy(Criteria.ACCURACY_FINE);
	    c.setAltitudeRequired(false);
	    c.setBearingRequired(false);
	    c.setCostAllowed(true);
	    c.setPowerRequirement(Criteria.POWER_LOW);
	    Provider	= myLocationManager.getBestProvider(c, true);
	    Log.i(TAG,"The best provider is " + Provider);
	    return Provider;
    }
    
    private void changeLocationManager(String provider, LocationManager lm)
    {
    	if (lm == null)
    		return;
    	if (myLocationListener == null)
    		return;
    	lm.requestLocationUpdates(provider,500, 1, myLocationListener);
    }

  //���� �� ��ġ�� GeoPoint�� �����Ѵ�.
    private GeoPoint getMyLocation()
    {
	    String provider;

	    if (bInit == true)
	    {
		    GeoPoint p = new GeoPoint(myLat.intValue(), myLng.intValue());
		    return p;
	    }

	    //GPS�� �����ִ��� Ȯ���Ѵ�.
	    myLocationManager	= (LocationManager)getSystemService(android.content.Context.LOCATION_SERVICE);

	    provider		= changeProvider();

	    //	������ ��ġ ��� ����
	    Location loc	= myLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
	    if (loc != null)
	    {
	    	myLat		= loc.getLatitude()*1E6;
	    	myLng		= loc.getLongitude()*1E6;
	    }

	    myLocationListener	= new LocationListener()
	    {
	    	@Override
		    public void onStatusChanged(String provider, int status, Bundle extras)
	    	{
	    		Log.i(TAG,"onStatusChanged(" + provider + ", " + status + ", " + extras + ")");
	    		String pv	= changeProvider();
	    		changeLocationManager(pv, myLocationManager);
		    }

		    @Override
		    public void onProviderEnabled(String provider)
		    {
		    	Log.i(TAG,"onProviderEnabled(" + provider + ")");
	    		String pv	= changeProvider();
	    		changeLocationManager(pv, myLocationManager);
		    }
		    @Override
		    public void onProviderDisabled(String provider)
		    {
		    	Log.i(TAG,"onProviderDisabled(" + provider + ")");
	    		String pv	= changeProvider();
	    		changeLocationManager(pv, myLocationManager);
		    }
		    //��ġ ������ ���� ���� �� ��ġ ������ �����´�.
		    @Override
		    public void onLocationChanged(Location location)
		    {
//	    		String pv = changeProvider();
//	    		changeLocationManager(pv, myLocationManager);

		    	Log.i(TAG,"onLocationChanged(Lat:"+location.getLatitude()*1E6 +" Lng:"+location.getLongitude()*1E6 + " accuracy : " + location.getAccuracy() + ")");
				if (location.getAccuracy() <= 70.0)
				{
					myLat				= location.getLatitude()*1E6;
					myLng				= location.getLongitude()*1E6;
					GeoPoint point		= new GeoPoint(myLat.intValue(), myLng.intValue());

					mapControl.setCenter(point);
					myPositionOverlay.setItem(point);
//			        OverlayItem myPosition	= new OverlayItem(p, "DisasterMap", "This point is my position!!");
//			        itemizedoverlayflood.addOverlay(myPosition);
			    	Log.i(TAG,"onLocationChanged(Lat:"+location.getLatitude()+" Lng:"+location.getLongitude() + ")");
				}
		    }
	    };

	    //���ǿ����� ���� ��ġ ������ �� ��� ������Ʈ �ϵ��� ����
	    changeLocationManager(provider, myLocationManager);

	    //���� ��ġ ������ GeoPoint�� �����Ѵ�.
	    GeoPoint p		= new GeoPoint(myLat.intValue(), myLng.intValue());
	    bInit			= true;
	    return p;
    }

    public void onPause()
    {
    	super.onPause();
    	Log.i(TAG,"onPause");
    	if (_timer != null)
    	{
	    	_timer.cancel();
	    	_timer	= null;
    	}
    }

    public void onClick()
    {
       Show();
    }

    Pop pop;
    private void Show()
    {
    	Log.i(TAG,"onclick");
		pop = new Pop(findViewById(R.id.mapview));  
		pop.show();  //popview�� ���
    }
}
