package com.lsy.buslocation.utility;

import com.google.android.maps.GeoPoint;

public class CalcPos
{
//	private static final int	area400	= 4000;	//	GeoPoint�� �뷫 500m �̳��� �Ÿ�
	private static final int	area400	= 4000;	//	GeoPoint�� �뷫 500m �̳��� �Ÿ�
	public boolean isInArea(GeoPoint point1, GeoPoint point2)
	{
		int	diffLatitude	= point1.getLatitudeE6() - point2.getLatitudeE6(); 
		int	diffLongitude	= point1.getLongitudeE6() - point2.getLongitudeE6();

		if (diffLatitude < 0)
			diffLatitude *= -1;

		if (diffLongitude < 0)
			diffLongitude *= -1;

		return (area400 >= diffLatitude) && (area400 >= diffLongitude);
	}
}
