package com.lsy.buslocation.utility;

import java.util.ArrayList;

import android.graphics.drawable.Drawable;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.OverlayItem;

public class MyPositionItemizedOverlay extends ItemizedOverlay<OverlayItem>
{
	static final String				TAG = "BusLocation";
	private ArrayList<OverlayItem> locations = new ArrayList<OverlayItem>();

	public MyPositionItemizedOverlay(Drawable drawable)
	{
		super(boundCenterBottom(drawable));
		// TODO Auto-generated constructor stub
	}

	@Override
	protected OverlayItem createItem(int i)
	{
		// TODO Auto-generated method stub
		return locations.get(i);
	}

	@Override
	public int size()
	{
		// TODO Auto-generated method stub
		return locations.size();
	}

	@Override
	protected boolean onTap(int index)
	{
		// TODO Auto-generated method stub
//		Log.i(TAG, "ItemizedOverlay onTap(" + index + "/" + size() + ")");
//		deleteAll();
//		Log.i(TAG, "ItemizedOverlay size after removing(" + size() + ")");
		return true;
	}

	public void addOverlay(GeoPoint pt)
	{
		// TODO Auto-generated method stub
		OverlayItem item	= new OverlayItem(pt, "", "");
		locations.add(item);
		populate();
	}

	public void deleteOverlay(int index)
	{
		locations.remove(index);
	}

	public void deleteAll()
	{
		locations.clear();
	}
}
