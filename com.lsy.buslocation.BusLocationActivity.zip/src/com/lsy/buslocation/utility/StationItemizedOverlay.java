package com.lsy.buslocation.utility;


import java.util.ArrayList;

import android.graphics.drawable.Drawable;
import android.util.Log;
//import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.OverlayItem;
import com.lsy.buslocation.BusLocationActivity;
import com.lsy.buslocation.service.Station;

public class StationItemizedOverlay extends ItemizedOverlay<OverlayItem>
{
	static final String				TAG					= "BusLocation";
	private ArrayList<OverlayItem>	locations			= new ArrayList<OverlayItem>();
	private ArrayList<Station>		stationArray		= new ArrayList<Station>();
	private BusLocationActivity		busLocationActivity	= null;

	public StationItemizedOverlay(Drawable drawable)
	{
		super(boundCenterBottom(drawable));
		// TODO Auto-generated constructor stub
	}

	@Override
	protected OverlayItem createItem(int i)
	{
		// TODO Auto-generated method stub
		return locations.get(i);
	}

	@Override
	public int size()
	{
		// TODO Auto-generated method stub
		return locations.size();
	}

	@Override
	protected boolean onTap(int index)
	{
		Log.i(TAG, "StationItemizedOverlay onTap(" + index + "/" + stationArray.size() + ")");
		if (index >= stationArray.size())
			return false;

		busLocationActivity.drawBusNearStation(stationArray.get(index));
		return true;
	}

	public void setBusLocationActivity(BusLocationActivity Activity)
	{
		busLocationActivity	= Activity;
	}

	public void addOverlay(GeoPoint pt, Station station)
	{
		// TODO Auto-generated method stub
		OverlayItem item	= new OverlayItem(pt, "", "");
		locations.add(item);
		stationArray.add(station);
		populate();
	}

	public void deleteOverlay(int index)
	{
		Log.i(TAG, "StationItemizedOverlay deleteOverlay(" + index + "/" + locations.size() + ")");
		locations.remove(index);
		stationArray.remove(index);
	}

	public void deleteAll()
	{
		Log.i(TAG, "StationItemizedOverlay deleteAll");
		locations.clear();
		stationArray.clear();
	}
}
