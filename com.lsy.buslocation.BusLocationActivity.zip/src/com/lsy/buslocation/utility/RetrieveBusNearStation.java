package com.lsy.buslocation.utility;

import java.util.ArrayList;

import android.util.Log;

import com.lsy.buslocation.service.BusPosByRtid;
import com.lsy.buslocation.service.BusPosClass;
import com.lsy.buslocation.service.BusRouteClass;
import com.lsy.buslocation.service.RouteByStation;
import com.lsy.buslocation.service.Station;

public class RetrieveBusNearStation
{
	static final String		TAG 		= "BusLocation";
    CalcPos					cp			= new CalcPos();

    public ArrayList<BusPosClass> findBusNearStation(Station station)
	{
        BusPosClass				busPos;//			= (BusPosClass)busPosList.getInfo(busRoute.getBusRouteId());
        BusRouteClass			busRoute;
        int						busRouteCount	= 0;
        int						inserteditem	= 0;
        ArrayList<BusPosClass>	busPosArray	= new ArrayList<BusPosClass>();

        RouteByStation	busRouteByStation	= new RouteByStation();
        busRoute							= (BusRouteClass)busRouteByStation.getInfo(station.getArsId());
        BusPosByRtid	busPosList			= new BusPosByRtid();

        busRouteCount						= busRouteByStation.NodeList.size();
        Log.i(TAG, "findBusNearStation(arsId = " + station.getArsId() + ", stationId = " + station.getStationId() + ", stationNm = " + station.getStationNm() +")");
        for (int i = 0; i < busRouteCount; i++)
        {
        	busRoute	= (BusRouteClass)busRouteByStation.NodeList.get(i);
        	if (busPosList.getInfo((Object)busRoute) == null)
        		break;
        	for (int j = 0; j < busPosList.NodeList.size(); j++)
        	{
        		busPos		= (BusPosClass)busPosList.NodeList.get(j);

        		if (cp.isInArea(station.getPosition(), busPos.getPosition()))
        		{
        			busPosArray.add(busPos);
        			inserteditem++;
//        			Log.i(TAG, busRoute.getBusRouteNm() + "�� ���� �߰�, ���� ��ȣ " + busPos.getPlainNo());
        		}
        	}
        }

        Log.i(TAG, "findBusNearStation inserted " + inserteditem + " items.");

        if (busPosArray.size() > 0)
        	return busPosArray;
        else
        	return null;
	}
}
