package com.lsy.buslocation.utility;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.MapView.LayoutParams;
import com.google.android.maps.OverlayItem;
import com.lsy.buslocation.R;
import com.lsy.buslocation.service.BusPosClass;


public class BusItemizedOverlay extends ItemizedOverlay<OverlayItem>
{
	static final String				TAG = "BusLocation";
	private MapView 				busMapView		= null;
	private ArrayList<OverlayItem>	locations		= new ArrayList<OverlayItem>();
	private ArrayList<BusPosClass>	busPosList		= new ArrayList<BusPosClass>();

	public BusItemizedOverlay(Drawable drawable, MapView mapView)
	{
		super(boundCenterBottom(drawable));
		busMapView	= mapView;
	}

	@Override
	protected OverlayItem createItem(int i)
	{
		// TODO Auto-generated method stub
		return locations.get(i);
	}

	@Override
	public int size()
	{
		return locations.size();
	}

	@Override
	protected boolean onTap(int index)
	{
		/*
	    Pop pop;

		Log.i(TAG,"onclick");
		pop = new Pop(busMapView);
		pop.show();  //popview�� ���
		*/
		/* ������ ��� */
		Log.i(TAG,"onTap");
		
		PopupWindow popupWindow;
		View		popupView;
		RelativeLayout	relative;
		final Button btnshow;

		busMapView.
		btnshow		= (Button)busMapView.findViewById(R.id.button1);
		if (btnshow == null)
		{
			Log.i(TAG,"no button");
			return true;
		}
		relative	= (RelativeLayout)busMapView.findViewById(R.id.mainlayout);
		if (relative == null)
		{
			Log.i(TAG,"no relative");
			return true;
		}
		popupView	= View.inflate(busMapView.getContext(), R.layout.popupwindow, null);
		if (popupView == null)
		{
			Log.i(TAG,"no popupView");
			return true;
		}
		popupWindow	= new PopupWindow(popupView, 2000, 100, true);
		if (popupWindow == null)
		{
			Log.i(TAG,"no popupWindow");
			return true;
		}

		popupWindow.setAnimationStyle(-1);
		popupWindow.showAsDropDown(null);
		//LayoutInflater layoutInflater = (LayoutInflater) busMapView.getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);
		//LayoutInflater layoutInflater = (LayoutInflater) busMapView.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		//View popupView = layoutInflater.inflate(R.layout.popupwindow, null);
		//final PopupWindow popupWindow = new PopupWindow(popupView, LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		//final PopupWindow popupWindow = new PopupWindow(popupView, 200, 300);

		//popupWindow.showAsDropDown(busMapView/*popupWindow*/, 0, (int)10/*popupWindow.getY()*/); // �˾� �����츦 ����ϴ� ���
		// ���⼭ ��ư�� GetY��ŭ ����� ������ ���̽��� ���ð� ����
		//��ư �ٷ� �Ʒ��� �˾��� ��Ÿ������ �ϱ� �����Դϴ�.	
		return true;
	}

	public void addOverlay(GeoPoint pt, BusPosClass busPos)
	{
		OverlayItem item	= new OverlayItem(pt, "", "");
		locations.add(item);
		busPosList.add(busPos);
		populate();
	}

	public void deleteOverlay(int index)
	{
		Log.i(TAG, "BusItemizedOverlay deleteOverlay(" + index + "/" + locations.size() + ")");
		locations.remove(index);
		busPosList.remove(index);
	}

	public void deleteAll()
	{
		Log.i(TAG, "BusItemizedOverlay deleteAll");
		locations.clear();
		busPosList.clear();
	}

	public BusPosClass getBusPosItem(int index)
	{
		Log.i(TAG, "BusItemizedOverlay getBusPosItem(" + index + "/" + locations.size() + ")");
		if (index >= busPosList.size())
		{
			Log.e(TAG, "BusItemizedOverlay getBusPosItem out of range");
			return null;
		}

		return busPosList.get(index);
	}
}
