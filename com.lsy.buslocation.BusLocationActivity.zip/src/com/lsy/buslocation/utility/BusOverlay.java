package com.lsy.buslocation.utility;

import java.util.List;

import android.graphics.drawable.Drawable;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.lsy.buslocation.service.BusPosClass;

public class BusOverlay extends Overlay
{
	private static final String		TAG = "BusLocation";
	private Drawable				busMarker;
	private MapView 				busMapView;
	private List<Overlay>			busOverlays;
	private BusItemizedOverlay		busItemizedOverlay;

	public BusOverlay(Drawable marker, MapView mapView)
	{
		setMarker(marker);
		setMapview(mapView);
		busItemizedOverlay = new BusItemizedOverlay(busMarker, mapView);
	}

	public boolean setMarker(Drawable marker)
	{
		busMarker	= marker;
		return true;
	}

	public boolean setMapview(MapView mapView)
	{
		busMapView	= mapView;
		busOverlays	= busMapView.getOverlays(); 
		return true;
	}

	public boolean addItem(GeoPoint point, BusPosClass busPos)
	{
		busItemizedOverlay.addOverlay(point, busPos);
		busOverlays.add(busItemizedOverlay);

		return true;
	}

	public BusPosClass getBusPosItem(int index)
	{
		return busItemizedOverlay.getBusPosItem(index);
	}

	public boolean clear()
	{
		Log.i(TAG, "BusOverlay clear()");
		busItemizedOverlay.deleteAll();

		for (int i = busOverlays.size() - 1; i >= 0; i--)
		{
			if (busOverlays.get(i) == busItemizedOverlay)
			{
				busOverlays.remove(i);
			}
		}
		return true;
	}

	public boolean onTap(GeoPoint p, MapView mapView)
	{
		Log.i(TAG, "busOverlay onTap()");
		return false;
	}

	public int size()
	{
		return busOverlays.size();
	}
	

}
