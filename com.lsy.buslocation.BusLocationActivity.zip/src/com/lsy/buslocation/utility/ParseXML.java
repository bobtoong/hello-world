package com.lsy.buslocation.utility;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.util.Log;
//import android.widget.Toast;

public class ParseXML
{
	private static final String				TAG = "BusLocation";

	private Element			m_rootelement;
	private NodeList		m_nodeList;
//	private int				m_nIndex	= 0;

	public int Parse(String Buf)
	{
		try
        {
            DocumentBuilderFactory	factory			= DocumentBuilderFactory.newInstance();
            DocumentBuilder			documentBuilder	= factory.newDocumentBuilder();
            //xml�� InputStream���·� ��ȯ
            InputStream				is				= new ByteArrayInputStream(Buf.getBytes());
            //document�� element �� w3c dom�� �ִ°��� ����Ʈ �Ѵ�.
            Document doc							= documentBuilder.parse(is);
            m_rootelement							= doc.getDocumentElement();
            m_nodeList								= m_rootelement.getChildNodes();
       }

       catch (Exception e)
       {
    	   Log.e(TAG, "Exception occurred during Parse [" + e.getMessage() + "]");
    	   return 0;
       }

//		m_nIndex	= 0;
		return m_nodeList.getLength();
	}

	public Node getNode(int i)
	{
		return m_nodeList.item(i);
	}

	public String getChildEliment(int i)
	{
		Node	node	= m_nodeList.item(i);
		return node.getNodeName();
	}

	public String getEliment(String TagName, int seq)
	{
		try
		{
			NodeList	items		= m_rootelement.getElementsByTagName(TagName);
	
			Node		item		= items.item(seq);
			Node		text		= item.getFirstChild();
			String 		itemValue	= text.getNodeValue();

	        return itemValue;
		}

        catch (Exception e)
        {
        	Log.d(TAG, "Exception occurred during getEliment [" + e.getMessage() + "]");
        	return "";
        }
	}

	public int getResult()
	{
		String	result = getEliment("headerCd", 0);
		return Integer.parseInt(result);
	}

	public boolean isOK()
	{
		String	result = getEliment("headerCd", 0);

		switch (Integer.parseInt(result))
		{
			//	success
			case 0 :
				return true;
			case 1 :
			{
				//Toast.makeText(this, "", Toast.LENGTH_LONG).show();
			}
			case 2 :
			case 3 :
			case 4 :
			case 5 :
			case 6 :
			case 7 :
			case 8 :
			case 20 :
			case 21 :
			case 22 :
			case 23 :
			case 31 :
			case 32 :
			case 99 :
		}
		return false;
	}
	

}
