package com.lsy.buslocation.utility;

import java.util.List;

import android.graphics.drawable.Drawable;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;

public class MyPositionOverlay extends Overlay
{
	static final String				TAG = "BusLocation";
	private Drawable					myPositionMarker;
	private MapView 					myPositionMapView;
	private List<Overlay>				myPositionOverlays;
	private MyPositionItemizedOverlay	myPositionItemizedOverlay;

	public MyPositionOverlay(Drawable marker, MapView mapView)
	{
		setMarker(marker);
		setMapview(mapView);
		myPositionItemizedOverlay = new MyPositionItemizedOverlay(myPositionMarker);
	}

	public boolean setMarker(Drawable marker)
	{
		myPositionMarker	= marker;
		return true;
	}

	public boolean setMapview(MapView mapView)
	{
		myPositionMapView	= mapView;
		myPositionOverlays	= myPositionMapView.getOverlays(); 
		return true;
	}

	public boolean setItem(GeoPoint point)
	{
//		myPositionOverlays.clear();

		for (int i = myPositionOverlays.size() - 1; i >= 0; i--)
		{
			if (myPositionOverlays.get(i) == myPositionItemizedOverlay)
			{
				myPositionOverlays.remove(i);
			}
		}

		myPositionItemizedOverlay.deleteAll();
		myPositionItemizedOverlay.addOverlay(point);
		myPositionOverlays.add(myPositionItemizedOverlay);
		return true;
	}

	public boolean onTap(GeoPoint p, MapView mapView)
	{
		Log.i(TAG, "busOverlay onTap()");
		return false;
	}
}
