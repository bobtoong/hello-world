package com.lsy.buslocation.utility;

import java.util.List;
//import com.lsy.buslocation.utility.*;
import android.graphics.drawable.Drawable;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.lsy.buslocation.BusLocationActivity;
import com.lsy.buslocation.service.Station;

public class StationOverlay extends Overlay 
{
	static final String				TAG = "BusLocation";
	private Drawable				stationMarker;
	private MapView 				stationMapView;
	private List<Overlay>			stationOverlays;
	private StationItemizedOverlay	stationItemizedOverlay;

	public StationOverlay(Drawable marker, MapView mapView)
	{
		setMarker(marker);
		setMapview(mapView);
		stationItemizedOverlay = new StationItemizedOverlay(stationMarker);
	}

	public boolean setMarker(Drawable marker)
	{
		stationMarker	= marker;
		return true;
	}

	public boolean setMapview(MapView mapView)
	{
		stationMapView	= mapView;
		stationOverlays	= stationMapView.getOverlays(); 

		return true;
	}

	public boolean addItem(GeoPoint point, Station station)
	{
		stationItemizedOverlay.addOverlay(point, station);
		stationOverlays.add(stationItemizedOverlay);

		return true;
	}

	public boolean clear()
	{
		Log.i(TAG, "StationOverlay clear()");
		stationItemizedOverlay.deleteAll();
		for (int i = stationOverlays.size() - 1; i >= 0; i--)
		{
			if (stationOverlays.get(i) == stationItemizedOverlay)
			{
				stationOverlays.remove(i);
			}
		}
//		stationOverlays.clear();
		return true;
	}

	public int size()
	{
		return stationOverlays.size();
	}
	
	public boolean onTap(GeoPoint p, MapView mapView)
	{
		Log.i(TAG, "StationOverlay onTap()");
		return false;
	}

	public void setBusLocationActivity(BusLocationActivity Activity)
	{
		stationItemizedOverlay.setBusLocationActivity(Activity);
	}
}
